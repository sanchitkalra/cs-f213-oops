package com.oops.csf213;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csf213ApplicationTests {

	@Test
	void contextLoads() {
	}

}
